resources = {
  "water": 400,
  "milk": 300,
  "coffee": 150,
}